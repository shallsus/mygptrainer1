package com.example.mygptrainer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
